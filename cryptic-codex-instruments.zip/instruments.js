/**
 * Cryptic Codex Terminal — Paranormal Instrument Controller
 * Three.js r128 integration for EMF Pressure Meter & SLS Lattice Scanner
 *
 * Drop this file into your Electron src/ directory.
 * Import and call initInstruments(scene, renderer) after Three.js setup.
 *
 * COLOUR ONTOLOGY (from design spec):
 *   Blue   0x00cfff — apparatus / infrastructure
 *   Green  0x00ff41 — SID / guidance
 *   Red    0xff2233 — corruption / escalation
 *   Purple 0xcc44ff — observatory / anomaly field
 *   Yellow 0xffcc00 — shrine / witness anomaly
 */

import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';

// ─── ANIMATION STATE MACHINE ─────────────────────────────────────────────────
const STATES = {
  IDLE:            'idle',
  SCANNING:        'scanning',
  SIGNAL_LOCK:     'signal_lock',
  ANOMALY_WARNING: 'anomaly_warning',
  CALIBRATION:     'calibration',
};

// ─── EMF PRESSURE METER ──────────────────────────────────────────────────────
export class EMFPressureMeter {
  constructor() {
    this.model       = null;
    this.parts       = {};          // name → THREE.Mesh
    this.state       = STATES.IDLE;
    this.emfLevel    = 0;           // 0.0–1.0, set by game system
    this._clock      = new THREE.Clock();
    this._ledMats    = [];          // ordered LED segment materials
    this._alertMat   = null;
    this._screenMat  = null;
    this._scanMixer  = null;
  }

  /** Load GLB. Returns Promise<this>. */
  async load(glbPath, scene) {
    const loader = new GLTFLoader();
    return new Promise((resolve, reject) => {
      loader.load(glbPath, (gltf) => {
        this.model = gltf.scene;
        scene.add(this.model);

        // Index all named meshes
        this.model.traverse((obj) => {
          if (obj.isMesh) {
            this.parts[obj.name] = obj;
            obj.castShadow    = true;
            obj.receiveShadow = true;

            // Collect LED segment materials (clone so we can animate independently)
            if (obj.name.startsWith('led_bar_seg_')) {
              const mat = obj.material.clone();
              obj.material = mat;
              this._ledMats.push({ mesh: obj, mat, index: parseInt(obj.name.slice(-2)) });
            }
            // Clone alert LED material
            if (obj.name === 'alert_led') {
              this._alertMat = obj.material.clone();
              obj.material = this._alertMat;
            }
            // Clone screen material
            if (obj.name === 'screen') {
              this._screenMat = obj.material.clone();
              obj.material = this._screenMat;
            }
          }
        });

        // Sort LEDs by index ascending
        this._ledMats.sort((a,b) => a.index - b.index);

        resolve(this);
      }, undefined, reject);
    });
  }

  /** Set EMF reading 0.0–1.0 from your game logic. */
  setEMFLevel(level) {
    this.emfLevel = Math.max(0, Math.min(1, level));
  }

  /** Transition to a new instrument state. */
  setState(newState) {
    if (!Object.values(STATES).includes(newState)) return;
    this.state = newState;
  }

  /** Call once per frame inside your animation loop. */
  update() {
    const t = this._clock.getElapsedTime();
    const dt = this._clock.getDelta();
    const lvl = this.emfLevel;

    // ── LED bar: light up segments proportional to EMF level
    const litCount = Math.round(lvl * this._ledMats.length);
    this._ledMats.forEach(({ mat, index }) => {
      const lit = index < litCount;
      if (lit) {
        // Colour: green (0-4), yellow (5-6), red (7)
        if (index < 5) {
          mat.emissive.setHex(0x00ff41);
          mat.emissiveIntensity = 0.8 + Math.sin(t * 8 + index) * 0.2;
        } else if (index < 7) {
          mat.emissive.setHex(0xffcc00);
          mat.emissiveIntensity = 0.9;
        } else {
          mat.emissive.setHex(0xff2233);
          mat.emissiveIntensity = 1.0;
        }
      } else {
        mat.emissive.setHex(0x000000);
        mat.emissiveIntensity = 0.0;
      }
    });

    // ── Alert LED: pulse on anomaly warning or high EMF
    if (this._alertMat) {
      const alertActive = this.state === STATES.ANOMALY_WARNING || lvl > 0.85;
      if (alertActive) {
        const pulse = (Math.sin(t * 10) * 0.5 + 0.5);
        this._alertMat.emissive.setHex(0xff2233);
        this._alertMat.emissiveIntensity = pulse;
      } else {
        this._alertMat.emissiveIntensity = lvl > 0.5 ? 0.15 : 0.0;
      }
    }

    // ── Screen glow: increases with EMF, flickers on anomaly
    if (this._screenMat) {
      let screenIntensity = 0.4 + lvl * 0.4;
      if (this.state === STATES.ANOMALY_WARNING) {
        screenIntensity *= (0.6 + Math.sin(t * 25) * 0.4);  // rapid flicker
      } else if (this.state === STATES.CALIBRATION) {
        screenIntensity = 0.15 + Math.sin(t * 2) * 0.1;     // slow breathe
      }
      this._screenMat.emissiveIntensity = screenIntensity;
    }

    // ── Device tilt: slight reactive lean based on EMF
    if (this.model) {
      const tiltTarget = lvl * 0.06 - 0.03;
      this.model.rotation.z += (tiltTarget - this.model.rotation.z) * 0.05;

      if (this.state === STATES.SCANNING) {
        this.model.rotation.z += Math.sin(t * 3) * 0.008;
      }
    }

    // ── Button depress animation (call via depressButton())
    // handled separately via depressButton()
  }

  /** Animate a button press. buttonName = 'button_hold'|'button_unit'|'button_power' */
  depressButton(buttonName, durationMs = 120) {
    const mesh = this.parts[buttonName];
    if (!mesh) return;
    const origZ = mesh.position.z;
    mesh.position.z += 0.002;           // press in
    setTimeout(() => { mesh.position.z = origZ; }, durationMs);
  }

  /** Quick positioning helper. */
  setPosition(x, y, z) { this.model?.position.set(x, y, z); }
  setScale(s)           { this.model?.scale.setScalar(s); }
  setRotation(x, y, z) { this.model?.rotation.set(x, y, z); }
}

// ─── SLS LATTICE SCANNER ─────────────────────────────────────────────────────
export class SLSLatticeScanner {
  constructor() {
    this.model          = null;
    this.parts          = {};
    this.state          = STATES.IDLE;
    this.scanActive     = false;
    this.formCount      = 0;          // number of detected skeletal forms
    this._clock         = new THREE.Clock();
    this._projMat       = null;
    this._displayMat    = null;
    this._lensMat       = null;
    this._irMats        = [];
    this._coneMesh      = null;
    this._coneMat       = null;
    this._railSensMat   = null;

    // Lattice point overlay (instanced mesh for SLS dots projected in UI)
    this._latticePoints = null;
  }

  async load(glbPath, scene) {
    const loader = new GLTFLoader();
    return new Promise((resolve, reject) => {
      loader.load(glbPath, (gltf) => {
        this.model = gltf.scene;
        scene.add(this.model);

        this.model.traverse((obj) => {
          if (obj.isMesh) {
            this.parts[obj.name] = obj;
            obj.castShadow    = true;
            obj.receiveShadow = true;

            // Clone interactive materials
            if (obj.name === 'projector_array') {
              this._projMat = obj.material.clone();
              obj.material  = this._projMat;
            }
            if (obj.name === 'side_display') {
              this._displayMat = obj.material.clone();
              obj.material     = this._displayMat;
            }
            if (obj.name === 'main_lens' || obj.name === 'lens_inner_element') {
              const m = obj.material.clone();
              obj.material = m;
              if (obj.name === 'main_lens') this._lensMat = m;
            }
            if (obj.name === 'infrared_emitters') {
              this._irMats.push({ mesh: obj, mat: obj.material.clone() });
              obj.material = this._irMats[this._irMats.length-1].mat;
            }
            if (obj.name === 'scan_light_cone') {
              this._coneMat  = obj.material.clone();
              obj.material   = this._coneMat;
              this._coneMesh = obj;
              obj.visible    = false;  // hidden until scan active
            }
            if (obj.name === 'rail_sensor_nodes') {
              this._railSensMat = obj.material.clone();
              obj.material = this._railSensMat;
            }
          }
        });

        resolve(this);
      }, undefined, reject);
    });
  }

  /** Activate or deactivate the scan cone. */
  setScanActive(active) {
    this.scanActive = active;
    if (this._coneMesh) this._coneMesh.visible = active;
  }

  /** 0–4 detected skeletal forms, influences intensity. */
  setFormCount(n) {
    this.formCount = Math.max(0, n);
    if (n > 0) this.setState(STATES.SIGNAL_LOCK);
    else if (this.scanActive) this.setState(STATES.SCANNING);
    else this.setState(STATES.IDLE);
  }

  setState(newState) {
    if (!Object.values(STATES).includes(newState)) return;
    this.state = newState;
  }

  update() {
    const t   = this._clock.getElapsedTime();
    const lvl = Math.min(1, this.formCount / 3);

    // ── Projector array: pulse amber on scan
    if (this._projMat) {
      if (this.state === STATES.SCANNING || this.state === STATES.SIGNAL_LOCK) {
        const pulse = 0.5 + Math.sin(t * (this.state === STATES.SIGNAL_LOCK ? 12 : 4)) * 0.5;
        this._projMat.emissive.setHex(0xffcc00);
        this._projMat.emissiveIntensity = 0.6 + pulse * 0.6;
      } else if (this.state === STATES.CALIBRATION) {
        this._projMat.emissive.setHex(0x00cfff);
        this._projMat.emissiveIntensity = 0.3 + Math.sin(t * 1.5) * 0.2;
      } else {
        this._projMat.emissiveIntensity = 0.1;
      }
    }

    // ── Side display: blue apparatus readout
    if (this._displayMat) {
      let di = 0.3;
      if (this.state === STATES.ANOMALY_WARNING) {
        di = 0.5 + Math.sin(t * 15) * 0.5;  // strobe
        this._displayMat.emissive.setHex(0xff2233);
      } else {
        this._displayMat.emissive.setHex(0x00cfff);
        di = this.state === STATES.IDLE ? 0.25 : 0.5 + Math.sin(t * 2) * 0.15;
      }
      this._displayMat.emissiveIntensity = di;
    }

    // ── Lens: flicker on anomaly lock
    if (this._lensMat) {
      if (this.state === STATES.SIGNAL_LOCK) {
        const flicker = Math.random() > 0.85 ? 0.0 : 0.3 + lvl * 0.4;
        this._lensMat.emissiveIntensity = flicker;
        this._lensMat.emissive.setHex(0x00cfff);
      } else {
        this._lensMat.emissiveIntensity = 0.05;
      }
    }

    // ── IR emitters: purple pulse
    this._irMats.forEach(({ mat }, i) => {
      if (this.scanActive) {
        const phase = t * 6 + i * (Math.PI * 2 / 3);
        mat.emissive.setHex(0xcc44ff);
        mat.emissiveIntensity = 0.4 + Math.sin(phase) * 0.4;
      } else {
        mat.emissiveIntensity = 0.05;
      }
    });

    // ── Scan cone: fade in/out, animate opacity
    if (this._coneMat && this._coneMesh) {
      if (this.scanActive) {
        const alpha = 0.10 + Math.sin(t * 3) * 0.06;
        this._coneMat.opacity = alpha;
        this._coneMat.emissiveIntensity = 0.3 + Math.sin(t * 2) * 0.2;
        // Slowly rotate cone for scanning effect
        this._coneMesh.rotation.z = Math.sin(t * 0.8) * 0.05;
      }
    }

    // ── Rail sensors: cycle green on scan
    if (this._railSensMat) {
      this._railSensMat.emissive.setHex(0x00cfff);
      this._railSensMat.emissiveIntensity = this.scanActive
        ? 0.4 + Math.sin(t * 5) * 0.3
        : 0.1;
    }

    // ── Device micro-shake on anomaly
    if (this.model) {
      if (this.state === STATES.ANOMALY_WARNING) {
        this.model.rotation.x = (Math.random() - 0.5) * 0.015;
        this.model.rotation.y = (Math.random() - 0.5) * 0.015;
      } else {
        this.model.rotation.x *= 0.9;
        this.model.rotation.y *= 0.9;
      }
    }
  }

  /** Animate trigger depress. */
  depressTrigger(durationMs = 100) {
    const mesh = this.parts['trigger_button'];
    if (!mesh) return;
    const orig = mesh.position.z;
    mesh.position.z -= 0.005;
    setTimeout(() => { mesh.position.z = orig; }, durationMs);
  }

  setPosition(x, y, z) { this.model?.position.set(x, y, z); }
  setScale(s)           { this.model?.scale.setScalar(s); }
  setRotation(x, y, z) { this.model?.rotation.set(x, y, z); }

  /**
   * Generate instanced lattice point overlay in world space.
   * Call when you want to render SLS skeleton dots in 3D UI.
   * positions = array of THREE.Vector3
   */
  showLatticeOverlay(positions, scene) {
    if (this._latticePoints) scene.remove(this._latticePoints);

    const geo = new THREE.SphereGeometry(0.008, 4, 4);
    const mat = new THREE.MeshBasicMaterial({ color: 0xffcc00 });
    const mesh = new THREE.InstancedMesh(geo, mat, positions.length);
    const dummy = new THREE.Object3D();
    positions.forEach((p, i) => {
      dummy.position.copy(p);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
    });
    mesh.instanceMatrix.needsUpdate = true;
    this._latticePoints = mesh;
    scene.add(mesh);
  }

  clearLatticeOverlay(scene) {
    if (this._latticePoints) { scene.remove(this._latticePoints); this._latticePoints = null; }
  }
}

// ─── INITIALISER ─────────────────────────────────────────────────────────────
/**
 * Convenience init. Loads both instruments and returns them.
 *
 * Usage:
 *   const { emf, sls } = await initInstruments(scene, __dirname);
 *   // in animate():
 *   emf.setEMFLevel(myGameEMF);
 *   emf.update();
 *   sls.update();
 */
export async function initInstruments(scene, assetDir = './assets') {
  const emf = new EMFPressureMeter();
  const sls = new SLSLatticeScanner();

  await emf.load(`${assetDir}/emf_pressure_meter.glb`, scene);
  await sls.load(`${assetDir}/sls_lattice_scanner.glb`, scene);

  // Default placement — adjust to suit your camera/scene
  emf.setPosition(-0.35, 0, 0);
  emf.setScale(1.0);
  emf.setRotation(0, Math.PI * 0.1, 0);

  sls.setPosition(0.35, 0, 0);
  sls.setScale(1.0);
  sls.setRotation(0, -Math.PI * 0.15, 0);

  // Start EMF in idle
  emf.setState(STATES.IDLE);
  sls.setState(STATES.IDLE);

  console.log('[CrypticCodex] Instruments loaded.');
  return { emf, sls, STATES };
}

// ─── ANIMATION STATE REFERENCE ────────────────────────────────────────────────
/*
  STATES.IDLE
    EMF:  LED bar dim, screen low glow, alert off, device still
    SLS:  projector dim, display soft blue, cone hidden, rail sensors dim

  STATES.SCANNING
    EMF:  LED bar updates with emfLevel, screen medium glow, device slight tilt wobble
    SLS:  projector pulses amber (slow), IR emitters cycle purple, cone visible, rail active

  STATES.SIGNAL_LOCK
    EMF:  LED bar at peak, screen bright, optional tilt hold
    SLS:  projector rapid amber strobe, lens flickers blue, lattice overlay shown

  STATES.ANOMALY_WARNING
    EMF:  alert LED pulses red fast, screen flickers, all top LEDs red
    SLS:  display strobes red, device micro-shakes, IR bright

  STATES.CALIBRATION
    EMF:  screen slow breathe, LEDs step up one at a time, device still
    SLS:  projector cycles blue (not amber), all sensors dim sequence

  ── Game integration hooks ──────────────────────────────────────
  emf.setEMFLevel(0.0 – 1.0)       drives LED bar + alert
  sls.setFormCount(0–4)             drives lock state + lattice overlay
  sls.setScanActive(true/false)     shows/hides scan cone
  sls.showLatticeOverlay(positions, scene)  renders 3D skeleton dots
  emf.depressButton('button_hold')  physical button click animation
  sls.depressTrigger()              trigger pull animation
  emf.setState(STATES.*)            force state transition
  sls.setState(STATES.*)            force state transition
*/
